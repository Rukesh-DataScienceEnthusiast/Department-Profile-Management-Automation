from django.contrib import admin
from django.urls import include, path
from django.conf import settings
from django.conf.urls.static import static
from departmentprofile import views  # Adjust this import based on your project structure

urlpatterns = [
    path('', views.Department, name='Department'),
        path('studentlogin/', views.student_login, name='student_login'),
        path('stafflogin/', views.staff_login, name='staff_login'),
        path('student/', views.student, name='student'),
        path('staff/', views.staff, name='staff'),
        path('staffregister/', views.staff_register, name='staff_register'),
        path('classes/', views.classes, name='classes'),
        path('syllabus/', views.syllabus, name='syllabus'),
        path('materials/', views.materials, name='materials'),
        path('tasks/', views.tasks, name='tasks'),
        path('viewrequest/', views.staffrequest,name='requests'),
        path('studentregister/', views.student_register, name='student_register'),
        path('leaverequest/', views.studrequest,name='requests_stud'),
        path('viewsyllabus/', views.syllabus_stud,name='syllabus_stud'),
        path('viewclasses/', views.classes_stud,name='classes_stud'),
        path('viewtasks/', views.tasks_stud,name='tasks_stud'),
        path('viewmaterials/', views.materials_stud,name='materials_stud'),
        path('admin/', admin.site.urls),
        path('action/',views.action,name='action'),
        path('updel_classes/', views.updel_classes,name='updel_classes'),
        path('updel_tasks/', views.updel_tasks,name='updel_tasks'),
        path('updel_materials/', views.updel_materials,name='updel_materials'),
        path('updel_syllabus/', views.updel_syllabus,name='updel_syllabus'),

        # urls.py
        path('deletetasks/<int:id>/', views.deletetasks, name='deletetasks'),
        path('updatetasks/<int:id>/', views.updatetasks, name='updatetasks'),
        path('deletematerials/<int:id>/', views.deletematerials, name='deletematerials'),
        path('deletesyllabus/<int:id>/', views.deletesyllabus, name='deletesyllabus'),
        path('deleteclasses/<int:id>/', views.deleteclasses, name='deleteclasses'),
        path('updateclasses/<int:id>/', views.updateclasses, name='updateclasses'),
        path('updatesyllabus/<int:id>/', views.updatesyllabus, name='updatesyllabus'),
         path('updatematerials/<int:id>/', views.updatematerials, name='updatematerials'),

]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
