from django.shortcuts import render,redirect
from .models import StudentLogin,StaffLogin,StaffRegister,StudentRegister,TimeTable,Syllabus,Materials,Tasks,Leaverequest
from django.http import HttpResponse
from django.conf import settings
from django.contrib import messages
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.hashers import make_password,check_password
from django.core.files.storage import FileSystemStorage
from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User

def Department(request):
    return render(request, 'Department.html')

# views.py


def staff_login(request):
    if request.method == "POST":
        faculty_id = request.POST.get('faculty_id')
        faculty_password = request.POST.get('faculty_password')

        # Check if faculty_id exists in StaffRegister
        try:
            staff_member = StaffRegister.objects.get(faculty_id=faculty_id)
            if faculty_password == staff_member.faculty_password:
                # Password is correct
                hashed_password = staff_member.faculty_password  # Already hashed


                # Save login details
                StaffLogin.objects.create(
                    faculty_id=faculty_id,
                    faculty_password=hashed_password,
                    # login_time will be automatically set due to auto_now_add=True
                )
                return redirect('staff')  # Redirect to your staff dashboard URL
            elif faculty_password != staff_member.faculty_password:
                messages.error(request, 'Invalid Login Credentials')
        except StaffRegister.DoesNotExist:
            messages.error(request, 'You have not registered yet')
    return render(request,'staff_login.html')


def student_login(request):
    if request.method == "POST":
        student_id = request.POST.get('student_id')
        student_password = request.POST.get('student_password')

        # Check if student_id exists in StudentRegister (assuming you have a StudentRegister model)
        try:
            student_member = StudentRegister.objects.get(student_id=student_id)
            if student_password == student_member.student_password:
                # Password is correct
                encrypted_password = student_member.student_password  # Already hashed

                # Save login details (assuming you have a StudentLogin model)
                StudentLogin.objects.create(
                    student_id=student_id,
                    student_password=encrypted_password,
                    # login_time will be automatically set due to auto_now_add=True
                )
                return redirect('student')  # Redirect to your student dashboard URL
            else:
                messages.error(request, 'Invalid Login Credentials')
        except StudentRegister.DoesNotExist:
            messages.error(request, 'You have not registered yet')

    return render(request, 'studentlogin.html')

def student(request):
    return render(request, 'student.html')

def staff(request):
    return render(request, 'staff.html')


def staff_register(request):
    if request.method == 'POST':
        faculty_name = request.POST['FACNAM']
        faculty_id = request.POST['FACID']
        faculty_password = request.POST['staffpassword']
        faculty_repassword = request.POST['confpassword']

        if faculty_password != faculty_repassword:
            messages.error(request, 'Passwords doesnt match')
        else:
            StaffRegister.objects.create(
                faculty_name=faculty_name,
                faculty_id=faculty_id,
                faculty_password=faculty_password
            )
            return redirect('staff_login')

    return render(request, 'staff_register.html')




def materials(request):
    if request.method == "POST":
        class_name = request.POST.get('degree')
        subject = request.POST.get('sub')
        materials = request.FILES.get('mat')  # Use request.FILES to get the uploaded file
        additional_information = request.POST.get('additionalinfo')

        if materials:
            # Save the uploaded file
            fs = FileSystemStorage()
            filename = fs.save(materials.name, materials)

            # Create a Materials object
            Materials.objects.create(
                class_name=class_name,
                subject=subject,
                materials=filename,
                additional_information=additional_information
            )

            return redirect('updel_materials')
        else:
            return HttpResponse("No file uploaded")

    return render(request, 'materials.html')





def classes(request):
    if request.method == "POST":
        class_name = request.POST.get('degree')
        timetable = request.FILES['stt']
        fs = FileSystemStorage()
        filename = fs.save(timetable.name,timetable)
        uploaded_file_url = fs.url(filename)

        TimeTable.objects.create(
            class_name=class_name,
            timetable=filename
        )
        return redirect("updel_classes")
    return render(request, 'classes.html')

def syllabus(request):
    if request.method == "POST":
        class_name = request.POST['degree']
        syllabus = request.FILES['syllabus']
        fs = FileSystemStorage()
        filename = fs.save(syllabus.name, syllabus)
        uploaded_file_url = fs.url(filename)
        Syllabus.objects.create(
            class_name=class_name,
            syllabus=filename
        )
        return redirect("updel_syllabus")
    return render(request, 'syllabus.html')

def tasks(request):
    if request.method == "POST":
        class_name = request.POST['degree']
        task_name = request.POST['task']
        subject = request.POST['sub']
        task_type = request.POST['tasktype']
        task_nature = request.POST['nature']
        deadline = request.POST['dead']
        Tasks.objects.create(
            class_name=class_name,
            task_name=task_name,
            subject=subject,
            task_type=task_type,
            task_nature= task_nature,
            deadline=deadline
        )
        return redirect('updel_tasks')
    return  render(request,'tasks.html')

def staffrequest(request):
    req = Leaverequest.objects.all()
    return render(request,'requests.html',{'req':req})

def student_register(request):
    if request.method == "POST":
        student_name = request.POST['STUDNAME']
        student_id = request.POST['student_id']
        student_class = request.POST['classtype']
        student_password = request.POST['student_password']
        student_repassword = request.POST['confpassword']

        if student_password != student_repassword:
            messages.error(request, 'Passwords do not match. Please try again.')
            return render(request, 'student_register.html')
        else:
            StudentRegister.objects.create(
                student_name=student_name,
                student_id=student_id,
                student_class=student_class,
                student_password=student_password,
            )
            return redirect('student_login')
    return render(request, 'student_register.html')

def studrequest(request):
    if request.method == "POST":
        student_name = request.POST.get('studname')
        student_id = request.POST.get('studid')
        mentor = request.POST.get('menname')
        classteacher = request.POST.get('clsname')
        class_name = request.POST.get('degree')
        reason = request.POST.get('reason')
        request_type = request.POST.get('reqtype')
        daycount = request.POST.get('nod')
        hourscount = request.POST.get('noh')

        # Convert empty strings to None
        daycount = int(daycount) if daycount else None
        hourscount = int(hourscount) if hourscount else None

        Leaverequest.objects.create(
            student_name=student_name,
            student_id=student_id,
            mentor=mentor,
            classteacher=classteacher,
            class_name=class_name,
            reason=reason,
            request_type=request_type,
            daycount=daycount,
            hourscount=hourscount
        )
        return HttpResponse("Uploaded successfully")

    return render(request, 'requests_stud.html')


def syllabus_stud(request):
    syll = Syllabus.objects.all()
    return render(request,'syllabus_stud.html',{'syll':syll})

def classes_stud(request):
    timetables = TimeTable.objects.all()
    return render(request,'classes_stud.html',{'timetables': timetables})

def tasks_stud(request):
    tasks = Tasks.objects.all()
    return render(request,'tasks_stud.html',{'tasks': tasks})

def materials_stud(request):
    material = Materials.objects.all()
    return render(request,'materials_stud.html',{'material':material})





def updatetasks(request, id):
    task = get_object_or_404(Tasks, id=id)

    if request.method == "POST":
        task.class_name = request.POST['degree']
        task.task_name = request.POST['task']
        task.subject = request.POST['sub']
        task.task_type = request.POST['tasktype']
        task.task_nature = request.POST['nature']
        task.deadline = request.POST['dead']
        task.save()
        return redirect('updel_tasks')

    return render(request, 'updatetask.html', {'task': task})

def updateclasses(request, id):
    class_obj = get_object_or_404(TimeTable, id=id)

    if request.method == "POST":
        class_obj.class_name = request.POST['class_name']
        if 'timetable' in request.FILES:
            class_obj.timetable = request.FILES['timetable']
        class_obj.save()
        return redirect('updel_classes')

    return render(request, 'updateclasses.html', {'class': class_obj})

def updatesyllabus(request, id):
    syllabus = get_object_or_404(Syllabus, id=id)

    if request.method == "POST":
        syllabus.class_name = request.POST['class_name']
        if 'syllabus' in request.FILES:
            syllabus.syllabus = request.FILES['syllabus']
        syllabus.save()
        return redirect('updel_syllabus')

    return render(request, 'updatesyllabus.html', {'syllabus': syllabus})

def updatematerials(request, id):
    material = get_object_or_404(Materials, id=id)

    if request.method == "POST":
        material.class_name = request.POST['class_name']
        material.subject = request.POST['subject']
        if 'materials' in request.FILES:
            material.materials = request.FILES['materials']
        material.additional_information = request.POST['additional_information']
        material.save()
        return redirect('updel_materials')

    return render(request, 'updatematerials.html', {'material': material})

def action(request):
    return render(request,'action.html')



def updel_classes(request):
    timetables = TimeTable.objects.all()
    return render(request,'updel_classes.html',{'timetables':timetables})


def updel_materials(request):
    material = Materials.objects.all()
    return render(request,'updel_materials.html',{'material':material})

def updel_syllabus(request):
    syll = Syllabus.objects.all()
    return render(request,'updel_syllabus.html',{'syll':syll})

def updel_tasks(request):
    tasks = Tasks.objects.all()
    return render(request,'updel_tasks.html',{'tasks':tasks})
def deletematerials(request,id):
    Material_to_delete = Materials.objects.filter(id=id)
    Material_to_delete.delete()
    return redirect('updel_materials')
def deletesyllabus(request,id):
    Syllabus_to_delete = Syllabus.objects.filter(id=id)
    Syllabus_to_delete.delete()
    return redirect('updel_syllabus')
def deleteclasses(request, id):
    # Assuming 'name' is the value you want to filter by
    tt_to_delete = TimeTable.objects.filter(id=id)
    tt_to_delete.delete()
    return redirect('updel_classes')


def deletetasks(request, id):
    task_to_delete = Tasks.objects.filter(id=id)
    task_to_delete.delete()
    return redirect('updel_tasks')