from django.db import models
from django.utils import timezone

class StaffLogin(models.Model):
    faculty_id = models.CharField(max_length=10)
    faculty_password = models.CharField(max_length=100)
    login_time = models.DateTimeField(default=timezone.now)  #

class StudentLogin(models.Model):
    student_id = models.CharField(max_length=10)
    student_password = models.CharField(max_length=10)
    login_time = models.DateTimeField(default=timezone.now)

class StaffRegister(models.Model):
    faculty_name = models.CharField(max_length=10)
    faculty_id = models.CharField(max_length=10)
    faculty_password = models.CharField(max_length=10)


class StudentRegister(models.Model):
    student_name = models.CharField(max_length=50)
    student_id = models.CharField(max_length=10)
    student_class = models.CharField(max_length=20)
    student_password = models.CharField(max_length=10)

from django.db import models

class TimeTable(models.Model):
    class_name = models.CharField(max_length=50)
    timetable = models.FileField(upload_to='classes/')

class Syllabus(models.Model):
    class_name = models.CharField(max_length=50)
    syllabus = models.FileField(upload_to='syllabus/')

class Tasks(models.Model):
    class_name = models.CharField(max_length=50)
    task_name = models.CharField(max_length=50)
    subject = models.CharField(max_length=50)
    task_type= models.CharField(max_length=50)
    task_nature = models.CharField(max_length=50)
    deadline = models.DateField()

class Materials(models.Model):
    class_name = models.CharField(max_length=50)
    subject = models.CharField(max_length=50)
    materials = models.FileField(upload_to='materials/')
    additional_information = models.CharField(max_length=500)



class Leaverequest(models.Model):
    student_name = models.CharField(max_length=50)
    student_id = models.CharField(max_length=50)
    mentor = models.CharField(max_length=50)
    classteacher = models.CharField(max_length=50)
    class_name = models.CharField(max_length=50)
    reason = models.CharField(max_length=500)
    request_type = models.CharField(max_length=50)
    daycount = models.IntegerField(default=0,null=True,blank=True)
    hourscount = models.IntegerField(default=0,null=True,blank=True)