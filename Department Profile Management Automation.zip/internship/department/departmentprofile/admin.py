from django.contrib import admin
from .models import StudentLogin,StaffLogin,StaffRegister,StudentRegister,TimeTable,Syllabus,Materials,Tasks,Leaverequest

admin.site.register(StaffRegister)
admin.site.register(StudentRegister)
admin.site.register(StudentLogin)
admin.site.register(StaffLogin)
admin.site.register(TimeTable)
admin.site.register(Syllabus)
admin.site.register(Materials)
admin.site.register(Tasks)
admin.site.register(Leaverequest)